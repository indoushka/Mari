
Hooker.lib source is included with the Malcode Analyst Pack Sclog 
project.

http://labs.idefense.com/

It contains the OllyDbg Asm/Dsm engines Copyright (C) 2001 Oleh Yuschuk

parse_h is a crude utility to generate the hook wrappers from the
windows .h files. 


