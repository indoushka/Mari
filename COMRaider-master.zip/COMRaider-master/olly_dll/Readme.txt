

All C source is Copyright (C) 2001 Oleh Yuschuk.

These are free sources that are part of his freeware debugger
and released by him under GPL.

Unaltered copies can be downloaded here:

http://ollydbg.de/

For this library, they have been compiled as a reusable DLL.
The only alterations to his code were to change the calling
convention to the exported functions to __stdcall for compatability
with VB.  

Main purpose of these alterations so that his libraries could be used 
from Visual Basic.

